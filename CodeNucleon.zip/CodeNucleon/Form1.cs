﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using ScintillaNET;

namespace CodeNucleon
{
    public partial class Form1 : Form
    {
        private Process pythonProcess;
        private Process batchProcess;
        private string tempFilePath;
        private Panel panelOverlay;

        public Form1()
        {
            InitializeComponent();
            this.Resize += MainForm_Resize;
            runBtn.Visible = Properties.Settings.Default.BetaMode;
        }
        private void MainForm_Resize(object sender, EventArgs e)
        {
            int textBoxWidth = this.ClientSize.Width - 20;
            int textBoxHeight = this.ClientSize.Height - 50;
            // Update the size of the codeTextBox to match the size of the MainForm
            scintilla1.Size = new Size(textBoxWidth, textBoxHeight);
        }


        private void saveBtn1_Click(object sender, EventArgs e)
        {
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Add filters for supported programming languages
                saveFileDialog.Filter = "Lua Files (*.lua)|*.lua|" +
                                        "C++ Files (*.cpp;*.h)|*.cpp;*.h|" +
                                        "C Files (*.c;*.h)|*.c;*.h|" +
                                        "C# Files (*.cs)|*.cs|" +
                                        "Python Files (*.py)|*.py|" +
                                        "JavaScript Files (*.js)|*.js|" +
                                        "TypeScript Files (*.ts)|*.ts|" +
                                        "Java Files (*.java)|*.java|" +
                                        "HTML Files (*.html;*.htm)|*.html;*.htm|" +
                                        "CSS Files (*.css)|*.css|" +
                                        "PHP Files (*.php)|*.php|" +
                                        "Ruby Files (*.rb)|*.rb|" +
                                        "Swift Files (*.swift)|*.swift|" +
                                        "Go Files (*.go)|*.go|" +
                                        "SQL Files (*.sql)|*.sql|" +
                                        "XML Files (*.xml)|*.xml|" +
                                        "JSON Files (*.json)|*.json|" +
                                        "Batch Files (*.cmd;*.bat)|*.cmd;*.bat|" +
                                        "Text Files (*.txt)|*.txt|" +
                                        "All Files (*.*)|*.*";

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName;
                    string textToSave = scintilla1.Text;

                    File.WriteAllText(filePath, textToSave);
                    MessageBox.Show("File saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void settingsBtn_Click(object sender, EventArgs e)
        {
            SettingsForm settingsForm = new SettingsForm();
            settingsForm.ShowDialog();
        }


        private void openBtn_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            // Add filters for supported programming languages
            openFileDialog.Filter = "Lua Files (*.lua)|*.lua|" +
                                    "C++ Files (*.cpp;*.h)|*.cpp;*.h|" +
                                    "C Files (*.c;*.h)|*.c;*.h|" +
                                    "C# Files (*.cs)|*.cs|" +
                                    "Python Files (*.py)|*.py|" +
                                    "JavaScript Files (*.js)|*.js|" +
                                    "TypeScript Files (*.ts)|*.ts|" +
                                    "Java Files (*.java)|*.java|" +
                                    "HTML Files (*.html;*.htm)|*.html;*.htm|" +
                                    "CSS Files (*.css)|*.css|" +
                                    "PHP Files (*.php)|*.php|" +
                                    "Ruby Files (*.rb)|*.rb|" +
                                    "Swift Files (*.swift)|*.swift|" +
                                    "Go Files (*.go)|*.go|" +
                                    "SQL Files (*.sql)|*.sql|" +
                                    "XML Files (*.xml)|*.xml|" +
                                    "JSON Files (*.json)|*.json|" +
                                    "Batch Files (*.cmd;*.bat)|*.cmd;*.cmd|" +
                                    "Text Files (*.txt)|*.txt|" +
                                    "All Files (*.*)|*.*";
            openFileDialog.FilterIndex = 1;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string fileName = openFileDialog.FileName;
                string fileContent = File.ReadAllText(fileName);
                scintilla1.Text = fileContent;

                // Determine the language based on the file extension
                string extension = Path.GetExtension(fileName);
                string language = GetLanguageFromExtension(extension);

                // Select the language in the ComboBox
                if (!string.IsNullOrEmpty(language))
                {
                    int index = languageComboBox.Items.IndexOf(language);
                    if (index != -1)
                        languageComboBox.SelectedIndex = index;
                }
            }
        }
        private string GetLanguageFromExtension(string extension)
        {
            switch (extension)
            {
                case ".lua": return "Lua";
                case ".cpp": return "C++";
                case ".cs": return "C#";
                case ".c": return "C";
                case ".h": return "C";
                case ".py": return "Python";
                case ".js": return "JavaScript";
                case ".ts": return "TypeScript";
                case ".java": return "Java";
                case ".html": return "HTML";
                case ".css": return "CSS";
                case ".php": return "PHP";
                case ".rb": return "Ruby";
                case ".swift": return "Swift";
                case ".go": return "Go";
                case ".sql": return "SQL";
                case ".xml": return "XML";
                case ".json": return "JSON";
                case ".bat": return "Batch";
                case ".cmd": return "Batch";
                case ".txt": return "Text";
                default: return null; // Unknown language or no extension
            }
        }

        private void ExecutePythonCode(string pythonCode)
        {
            // Save the Python code to a temporary file
            tempFilePath = Path.Combine(Path.GetTempPath(), $"{Guid.NewGuid()}.py");
            File.WriteAllText(tempFilePath, pythonCode);

            try
            {
                // Execute the Python file using the Python interpreter
                ProcessStartInfo startInfo = new ProcessStartInfo
                {
                    FileName = "python3",
                    Arguments = tempFilePath,
                    UseShellExecute = false,
                    CreateNoWindow = false
                };

                pythonProcess = Process.Start(startInfo);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error executing Python code: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExecuteBatchCode(string batchCode)
        {
            // Save the Python code to a temporary file
            tempFilePath = Path.Combine(Path.GetTempPath(), $"{Guid.NewGuid()}.bat");
            File.WriteAllText(tempFilePath, batchCode);

            try
            {
                // Execute the Python file using the Python interpreter
                ProcessStartInfo startInfo = new ProcessStartInfo
                {
                    FileName = "cmd",
                    Arguments = tempFilePath,
                    UseShellExecute = false,
                    CreateNoWindow = false
                };

                batchProcess = Process.Start(startInfo);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error executing Batch code: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void runBtn_Click(object sender, EventArgs e)
        {
            if (languageComboBox.SelectedIndex != 4)
            {
                MessageBox.Show("Currently, only Python is supported to be ran by CodeNucleon.");

            }
            else
            {
                /*
                if(languageComboBox.SelectedIndex != languageComboBox.Items.IndexOf("Batch"))
                {
                    string batchCode = codeTextBox.Text;
                    ExecuteBatchCode(batchCode);
                }
                else
                {
                */
                string pythonCode = scintilla1.Text;
                ExecutePythonCode(pythonCode);
                //}
            }

        }

        private void MainForm_Closing(object sender, FormClosingEventArgs e)
        {
            // Check if the Python process is running
            if (pythonProcess != null && !pythonProcess.HasExited)
            {
                // Terminate the Python process
                pythonProcess.Kill();
            }

            // Check if the Batch process is running
            if (batchProcess != null && !batchProcess.HasExited)
            {
                // Terminate the Batch process
                batchProcess.Kill();
            }

            // Delete the temporary file if it exists
            if (File.Exists(tempFilePath))
            {
                File.Delete(tempFilePath);
            }
        }
        private void code_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
        }

        private void code_DragDrop(object sender, DragEventArgs e)
        {
            // Check if the drop occurred over the RichTextBox
            Point clientPoint = scintilla1.PointToClient(new Point(e.X, e.Y));
            if (scintilla1.ClientRectangle.Contains(clientPoint))
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files.Length > 0)
                {
                    string filePath = files[0]; // Assuming only one file is dropped
                    string fileExtension = Path.GetExtension(filePath).ToLower();

                    // Set the language based on the file extension
                    string language = GetLanguageFromExtension(fileExtension);

                    // Select the language in the ComboBox
                    if (!string.IsNullOrEmpty(language))
                    {
                        int index = languageComboBox.Items.IndexOf(language);
                        if (index != -1)
                            languageComboBox.SelectedIndex = index;
                    }

                    // Open and display the file content in the code editor
                    scintilla1.Text = File.ReadAllText(filePath);
                }
            }
        }
        private void SetLanguage(string language)
        {
            int index = languageComboBox.Items.IndexOf(language);
            if (index != -1)
            {
                languageComboBox.SelectedIndex = index;
            }
        }


        private void code_TextChanged(object sender, EventArgs e)
        {
            string text = scintilla1.Text.ToLower(); // Convert text to lowercase for case-insensitive matching

            // Detect language based on keyword patterns
            if (text.Contains("class") || text.Contains("namespace") || text.Contains("using") || text.Contains("public"))
            {
                SetLanguage("C#");
            }
            else if (text.Contains("def") || text.Contains("import") || text.Contains("print") || text.Contains("for") || text.Contains("while") || text.Contains("async") || text.Contains("if __name__ == \"__main__\":"))
            {
                SetLanguage("Python");
            }
            else if (text.Contains("local") || text.Contains("function") || text.Contains("end"))
            {
                SetLanguage("Lua");
            }
            else if (text.Contains("int") || text.Contains("float") || text.Contains("double") || text.Contains("void") || text.Contains("include"))
            {
                SetLanguage("C++");
            }
            else if (text.Contains("#include") || text.Contains("cout") || text.Contains("cin") || text.Contains("namespace"))
            {
                SetLanguage("C++");
            }
            else if (text.Contains("printf") || text.Contains("scanf") || text.Contains("main"))
            {
                SetLanguage("C");
            }
            else if (text.Contains("var") || text.Contains("let") || text.Contains("const") || text.Contains("function") || text.Contains("=>") || text.Contains("async"))
            {
                SetLanguage("JavaScript");
            }
            else if (text.Contains("class") || text.Contains("extends") || text.Contains("static") || text.Contains("void") || text.Contains("main"))
            {
                SetLanguage("Java");
            }
            else if (text.Contains("<html>") || text.Contains("<head>") || text.Contains("<body>") || text.Contains("<div>") || text.Contains("<span>") || text.Contains("<p>") || text.Contains("<a ") || text.Contains("<img "))
            {
                SetLanguage("HTML");
            }
            else if (text.Contains("{") || text.Contains("}") || text.Contains(":") || text.Contains(";") || text.Contains("#") || text.Contains("body") || text.Contains("div") || text.Contains("p") || text.Contains("h1") || text.Contains("h2"))
            {
                SetLanguage("CSS");
            }
            else if (text.Contains("<?php") || text.Contains("?>") || text.Contains("echo") || text.Contains("$") || text.Contains("$_") || text.Contains("->"))
            {
                SetLanguage("PHP");
            }
            else if (text.Contains("def") || text.Contains("class") || text.Contains("module") || text.Contains("require") || text.Contains("puts") || text.Contains("end"))
            {
                SetLanguage("Ruby");
            }
            else if (text.Contains("import SwiftUI") || text.Contains("struct") || text.Contains("var") || text.Contains("let") || text.Contains("func") || text.Contains("print") || text.Contains("init") || text.Contains("body"))
            {
                SetLanguage("Swift");
            }
            else if (text.Contains("package") || text.Contains("import") || text.Contains("func") || text.Contains("var") || text.Contains("const") || text.Contains("fmt") || text.Contains("main"))
            {
                SetLanguage("Go");
            }
            else if (text.Contains("SELECT") || text.Contains("FROM") || text.Contains("WHERE") || text.Contains("JOIN") || text.Contains("INSERT INTO") || text.Contains("UPDATE") || text.Contains("DELETE FROM") || text.Contains("CREATE TABLE"))
            {
                SetLanguage("SQL");
            }
            else if (text.Contains("<xml>") || text.Contains("<element>") || text.Contains("<attribute>") || text.Contains("<value>") || text.Contains("<tag>") || text.Contains("<root>") || text.Contains("<data>"))
            {
                SetLanguage("XML");
            }
            else if (text.Contains("{") || text.Contains("[") || text.Contains(":") || text.Contains(",") || text.Contains("\"") || text.Contains("true") || text.Contains("false") || text.Contains("null"))
            {
                SetLanguage("JSON");
            }
            else if (text.Contains("@echo") || text.Contains("echo") || text.Contains("set") || text.Contains("if") || text.Contains("for") || text.Contains("goto") || text.Contains("pause") || text.Contains("rem"))
            {
                SetLanguage("Batch");
            }
            else
            {
                SetLanguage("Text");
            }
        }
    }
}
