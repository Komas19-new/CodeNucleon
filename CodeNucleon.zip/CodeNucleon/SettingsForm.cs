﻿using System;
using System.Windows.Forms;

namespace CodeNucleon
{
    public partial class SettingsForm : Form
    {

        public SettingsForm()
        {
            InitializeComponent();
            betaCheckBox.Checked = Properties.Settings.Default.BetaMode;
            discordrpcCheckBox.Checked = Properties.Settings.Default.DiscordRPC;
        }

        private void applyBtn_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.BetaMode = betaCheckBox.Checked;
            Properties.Settings.Default.DiscordRPC = discordrpcCheckBox.Checked;
            Properties.Settings.Default.Save();
            MessageBox.Show("Applied settings. You may need to restart for changes to take place.");
        }
    }
}
