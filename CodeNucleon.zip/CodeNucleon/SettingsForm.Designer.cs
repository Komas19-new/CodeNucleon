﻿namespace CodeNucleon
{
    partial class SettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.betaCheckBox = new System.Windows.Forms.CheckBox();
            this.applyBtn = new System.Windows.Forms.Button();
            this.discordrpcCheckBox = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // betaCheckBox
            // 
            this.betaCheckBox.AutoSize = true;
            this.betaCheckBox.Location = new System.Drawing.Point(13, 24);
            this.betaCheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.betaCheckBox.Name = "betaCheckBox";
            this.betaCheckBox.Size = new System.Drawing.Size(99, 21);
            this.betaCheckBox.TabIndex = 0;
            this.betaCheckBox.Text = "Beta Mode";
            this.betaCheckBox.UseVisualStyleBackColor = true;
            // 
            // applyBtn
            // 
            this.applyBtn.Location = new System.Drawing.Point(368, 293);
            this.applyBtn.Margin = new System.Windows.Forms.Padding(4);
            this.applyBtn.Name = "applyBtn";
            this.applyBtn.Size = new System.Drawing.Size(100, 30);
            this.applyBtn.TabIndex = 1;
            this.applyBtn.Text = "Apply";
            this.applyBtn.UseVisualStyleBackColor = true;
            this.applyBtn.Click += new System.EventHandler(this.applyBtn_Click);
            // 
            // discordrpcCheckBox
            // 
            this.discordrpcCheckBox.AutoSize = true;
            this.discordrpcCheckBox.Checked = true;
            this.discordrpcCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.discordrpcCheckBox.Location = new System.Drawing.Point(13, 53);
            this.discordrpcCheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.discordrpcCheckBox.Name = "discordrpcCheckBox";
            this.discordrpcCheckBox.Size = new System.Drawing.Size(115, 21);
            this.discordrpcCheckBox.TabIndex = 2;
            this.discordrpcCheckBox.Text = "Discord RPC";
            this.discordrpcCheckBox.UseVisualStyleBackColor = true;
            // 
            // SettingsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 339);
            this.Controls.Add(this.discordrpcCheckBox);
            this.Controls.Add(this.applyBtn);
            this.Controls.Add(this.betaCheckBox);
            this.Font = new System.Drawing.Font("Source Code Pro Black", 9.75F, System.Drawing.FontStyle.Bold);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "SettingsForm";
            this.Text = "SettingsForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox betaCheckBox;
        private System.Windows.Forms.Button applyBtn;
        private System.Windows.Forms.CheckBox discordrpcCheckBox;
    }
}